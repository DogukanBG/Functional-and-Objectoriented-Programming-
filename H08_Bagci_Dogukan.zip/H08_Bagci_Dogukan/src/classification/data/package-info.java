/**
 * Enthält Klassen und Interfaces zur Repräsentation beschrifteter und
 * unbeschrifteter Datensätze für das maschinelle Lernen.
 * 
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification.data;