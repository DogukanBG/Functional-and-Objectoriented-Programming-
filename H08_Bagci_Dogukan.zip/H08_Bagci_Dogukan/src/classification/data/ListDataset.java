package classification.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Collections;

public class ListDataset <S extends Sample<?>> implements Dataset<S> {
	
	private List <S> samples = new ArrayList<S>();

	public ListDataset() {
	
	}
	
	
	
	@Override
	public Iterator<S> iterator() {
		return samples.iterator();
	}

	@Override
	public void add(S sample) {
		samples.add(sample);
	}

	@Override
	public void shuffle() {
		Collections.shuffle(samples);
		
	}}
