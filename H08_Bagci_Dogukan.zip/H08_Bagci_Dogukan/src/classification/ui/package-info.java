/**
 * Enthält die UI-Komponenten, mit denen die Ergebnisse eines
 * Klassifizierungsexperimentes dargestellt werden können.
 *
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification.ui;
