/**
 * Enthält die Interfaces und Klassen, mit denen Datensätze von externen Quellen
 * eingelesen werden können.
 *
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification.io;
