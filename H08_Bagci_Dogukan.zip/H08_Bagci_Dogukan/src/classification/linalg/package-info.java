/**
 * Enthält die Klasse {@link Vector}, die für einfache Vektorraumalgebra in
 * endlich-dimensionalen reellen Räumen verwendet werden kann.
 *
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification.linalg;
