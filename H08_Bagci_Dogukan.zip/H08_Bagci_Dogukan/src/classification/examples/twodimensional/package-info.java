/**
 * Enthät die Klassen, die für einfache Experimente an zweidimensionalen
 * Datenpunkten verwendet werden.
 *
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification.examples.twodimensional;
