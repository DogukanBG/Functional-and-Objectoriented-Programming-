/**
 * Enthät die Klassen, die für Experimente mit dem berühmten
 * <a href=
 * "https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1469-1809.1936.tb02137.x">
 * Iris-Datensatz</a> benötigt werden.
 *
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification.examples.iris;
