/**
 * Enthät die Klassen, die für das Trainieren eines SMS-Spamfilters mit dem
 * <a href="https://www.researchgate.net/publication/221353226">Datensatz</a>
 * von Almeida, Gómez Hidalgo und Yamakami benötigt werden.
 *
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification.examples.sms;
