package classification.examples.generics;

import classification.data.Label;

/**
 * @author Kim Berninger
 * @version 1.0.0
 */
public enum Age implements Label {
}
