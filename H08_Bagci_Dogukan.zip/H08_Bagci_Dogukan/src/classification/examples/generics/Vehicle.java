package classification.examples.generics;

/**
 * @author Kim Berninger
 * @version 1.0.0
 */
class Vehicle {
}
