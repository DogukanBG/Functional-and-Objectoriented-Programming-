/**
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification.examples.generics;
