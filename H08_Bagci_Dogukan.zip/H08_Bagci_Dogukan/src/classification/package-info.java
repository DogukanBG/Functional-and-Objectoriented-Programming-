/**
 * Enthält Klassen, die verwendet werden, um Klassifizierungsexperimente
 * auszuführen.
 *
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification;
