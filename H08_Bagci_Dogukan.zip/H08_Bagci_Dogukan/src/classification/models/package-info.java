/**
 * Enthält Modelle, die für das maschinelle Lernen verwendet werden können. 
 * 
 * @author Kim Berninger
 * @version 1.0.0
 */
package classification.models;
