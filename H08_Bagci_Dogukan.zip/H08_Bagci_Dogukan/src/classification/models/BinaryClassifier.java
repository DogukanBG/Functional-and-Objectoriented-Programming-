package classification.models;

import java.util.List;
import classification.data.*;



/**
 * Dieses Interface definiert die grundlegenden Operationen eines allgemeinen
 * binären Klassifizierers.
 *
 * @author Kim Berninger
 * @version 1.0.0

 * @param <S> der Subtyp von {@link Sample}, dem die Elemente, mit denen dieser
 *            Klassifizierer trainiert werden soll, entsprechen sollen
 */
public interface BinaryClassifier<S extends Sample<? super S>> {
    <T extends S> List<Double> fit(Dataset<SupervisedSample<T,BinaryLabel>> data, int epochs);

   
	<T extends S> double evaluate(Dataset<SupervisedSample<T, BinaryLabel>> data);

  
	<T extends S > List<BinaryLabel> predict(Dataset<? extends Sample<? super T>> data);
}
