package classification.models;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import classification.data.BinaryLabel;
import classification.data.Dataset;
import classification.data.Label;
import classification.data.Sample;
import classification.data.SupervisedSample;
import classification.linalg.Vector;

public class SVM <S extends Sample<? super S>> implements BinaryClassifier <S> {
	
	private Vector weights;
	private double bias;
	private double lambda;
	
	public SVM (int dimension, double lambda) {
		Random random = new Random();
		this.weights = Vector.random(dimension);
		this.bias = random.nextGaussian();
		this.lambda = lambda;
	}
	
	public Vector getWeights() {
		return weights;
	}
	
	public double getBias() {
		return bias;
	}
	
	private <T extends S> double loss(SupervisedSample<T, BinaryLabel> sample) {
		int label = 1;
		if(sample.getLabel()==BinaryLabel.NEGATIVE) {
			label = -1;
		}
		double regul = (lambda/2)*(Math.pow(getWeights().norm(), 2)+Math.pow(getBias(), 2));
		return (double) Math.max(0, 1-label*(sample.getSample().getFeatures().dot(getWeights())+getBias())) + regul;
	}
	
	private <T extends S> Vector gradWeights(SupervisedSample<T, BinaryLabel> sample) {
		int y = 1;
		if(sample.getLabel()==BinaryLabel.NEGATIVE) {
			y = -1;
		}
		if (1-y*(sample.getSample().getFeatures().dot(getWeights())+getBias())<=0) {
			return getWeights().mul(lambda);
		}
		return getWeights().mul(lambda).sub(sample.getFeatures().mul(y));
	}
	
	private <T extends S> double gradBias (SupervisedSample<T, BinaryLabel> sample) {
		int y = 1;
		if(sample.getLabel()==BinaryLabel.NEGATIVE) {
			y = -1;
		}
		if (1-y*(sample.getSample().getFeatures().dot(getWeights())+getBias())<=0) {
			return getBias()*lambda;
		}
		return getBias()*lambda-y;
	}
	
	public <T extends S> List<Double> fit(Dataset<SupervisedSample<T, BinaryLabel>> data, int epochs) {
		int n = 0;
		for (SupervisedSample<T, BinaryLabel> supervisedSample : data) {
			n++;
		} 
		ArrayList<Double> result = new ArrayList<Double>();
		for (int i = 0; i < epochs; i++) {
			  result.add((double) 0);
		}
		for (int k=1; k<=epochs; k++) {
			//Mische D
			data.shuffle();
			//lk ---> 0
			result.set(k-1, (double) 0);
			for (SupervisedSample<T, BinaryLabel> supervisedSample : data) {
				//lk ---> lk + 1/n * loss
				result.set(k-1, (double)result.get(k-1) + (((double)1.0 / (double) n))*loss(supervisedSample));
				//w ---> w - gradW * 1/k 
				this.weights = getWeights().sub(gradWeights(supervisedSample).mul((double) 1.0/k));
				//b ---> b - 1/k * gradB
				this.bias = getBias()-((double)1.0/k)*gradBias(supervisedSample);
			}
		}
		return result;
	}
	
	public <T extends S> double evaluate(Dataset<SupervisedSample<T, BinaryLabel>> data) {
		 int tp = 0;
		 int tn = 0;
		 int fp = 0;
		 int fn = 0;
		 Iterator<SupervisedSample<T, BinaryLabel>> iterator = data.iterator();
		 List<BinaryLabel> labels = predict(data);
		 for (BinaryLabel binaryLabel : labels) {
			 SupervisedSample<T, BinaryLabel> sample = iterator.next();
			if (BinaryLabel.POSITIVE == sample.getLabel()) {
				if (binaryLabel == sample.getLabel()) {
					tp++;
				}
				else {
					fn++;
				}
			}
			if (BinaryLabel.NEGATIVE == sample.getLabel()) {
				if (binaryLabel == sample.getLabel()) {
					tn++;
				}
				else {
					fp++;
				}
			}
				
		}
		return (double) (tp+tn)/(tp+tn+fp+fn); 
	 }
	 
	public <T extends S> List<BinaryLabel> predict(Dataset<? extends Sample<? super T>> data){
		 int p = 0;
		 ArrayList<BinaryLabel> labels = new ArrayList<>();
		 Iterator<? extends Sample<? super T>> iterator = data.iterator();
		 while (iterator.hasNext()) {
			double pre = iterator.next().getFeatures().dot(getWeights())+getBias();
			if (pre>=0) {
				labels.add(p,BinaryLabel.POSITIVE);
				p++;
			}
			else {
				labels.add(p,BinaryLabel.NEGATIVE);
				p++;
			}
		}
		return labels;
	 }

	

	
	
	
	
}