package stone;

import main.TetrisGame;
import misc.Vector;
import robot.SquareRobot;

public abstract class Stone {

	///////////////
	// EXERCISES //
	///////////////

	/**
	 * Tries to rotate all square robots of this stone to the left.
	 * @return if the rotation was successful
	 */
	public boolean rotateAllLeft() {
		for(SquareRobot square:robots) {
			Vector[]vector=square.getRotationVectors();
			for(int i=0;i<4;i++) {
				if(!square.canMove(vector[i])){
					return false;
				}
			}
		}
		for (SquareRobot square : robots)
			square.rotateLeft();
		return true;
	}

	/**
	 * Handles the given key input.
	 * @param key the key input
	 */
	public void handleKeyInput(byte key) {
		Vector vector=new Vector(0,-1);
		if(key==0) {
			rotateAllLeft();
		}
		if(key==1) {
			moveAllLeft();
		}
		if(key==2) {
			moveAllDown();
		}
		if(key==3) {
			moveAllRight();
		}
		if(key==4) {
			while(moveAll(vector)) {
				moveAllDown();
			}
		}
		
	}

	// ---------------------------------------------------------------------------------------------------- //

	private final TetrisGame game;

	private SquareRobot[] robots;

	/**
	 * Constructs a {@link Stone}.
	 * @param game the game using this stone
	 */
	public Stone(TetrisGame game) {
		this.game = game;
	}

	/**
	 * Returns the game using this stone.
	 * @return the game using this stone
	 */
	public TetrisGame getRelatedGame() {
		return game;
	}

	/**
	 * Returns the square robot array of this stone.
	 * @return the square robot array of this stone
	 */
	public SquareRobot[] getSquareRobots() {
		return robots;
	}

	/**
	 * Tries to move all square robots of this stone by the given vector.
	 * @param vector the vector
	 * @return if the movement was successful
	 */
	public boolean moveAll(Vector vector) {
		for (SquareRobot square : robots)
			if (!square.canMove(vector))
				return false;
		for (SquareRobot square : robots)
			square.move(vector);
		return true;
	}

	/**
	 * Tries to move down all square robots of this stone.
	 * @return if the movement was successful
	 */
	public boolean moveAllDown() {
		return moveAll(Vector.of(0, -1));
	}

	/**
	 * Tries to move left all square robots of this stone.
	 * @return if the movement was successful
	 */
	public boolean moveAllLeft() {
		return moveAll(Vector.of(-1, 0));
	}

	/**
	 * Tries to move right all square robots of this stone.
	 * @return if the movement was successful
	 */
	public boolean moveAllRight() {
		return moveAll(Vector.of(1, 0));
	}

	/**
	 * Sets the array of square robots for this stone.
	 * @param if the array of square robots
	 */
	public void setSquareRobots(SquareRobot... robots) {
		this.robots = robots;
	}

}
