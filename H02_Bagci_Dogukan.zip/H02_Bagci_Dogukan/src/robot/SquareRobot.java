package robot;

import fopbot.*;
import fopbot.Direction.*;
import fopbot.Robot;
import misc.Vector;
import stone.Stone;
import main.TetrisGame;
public class SquareRobot extends Robot {

	///////////////
	// EXERCISES //
	///////////////
	
	/**
	 * Returns an array containing all possible movements of this square robot.
	 * @return an array containing all possible movements of this square robot
	 */
	public Vector[] getPossibleMovements() {
		int d=0;
		int height=getRelatedStone().getRelatedGame().getHeight();
		int width=getRelatedStone().getRelatedGame().getWidth();
		Vector[]vector=new Vector[height*width];
		for(int i=-12;i<12;i++) {
			for(int b=-8;b<8;b++) {
				vector[d]=new Vector (i,b);
				if(canMove(vector[d])) {
					d++;
				}
			}
		}
		System.out.println(vector);
		return vector;
	}

	/**
	 * Returns if this square robot can be moved by the given vector.
	 * @param vector the vector
	 * @return if this square robot can be move by the given vector
	 */
	public boolean canMove(Vector vector) {
		int height=getRelatedStone().getRelatedGame().getHeight();
		int width=getRelatedStone().getRelatedGame().getWidth();
		Stone [] stones = getRelatedStone().getRelatedGame().getStoneArray();
		if(vector.x+getX()<0) {
			return false;
		}
		if(vector.y+getY()<0)
			return false;
		for(int i=0;i<stones.length;i++)
			for(int b=0;b<4;b++) {
				if(stones[i]!=null) {
					if(vector.x==width&&vector.y==height)
						if(stones[i].getSquareRobots()[b].isTurnedOn() && 
							stones[i].getSquareRobots()[b].getX()==vector.x+getX() &&
							stones[i].getSquareRobots()[b].getY()==vector.y+getY()) {
								return false;
						}
				}
			}
		return true;
	}
	/**
	 * Rotates this square robot to the left.
	 */  
	public void rotateLeft() {
		int b=0;
		Vector[]vector= getRotationVectors();
		if(getDirection()==Direction.UP) {
			turnLeft();
			b=0;
		}
		else {
			if(getDirection()==Direction.LEFT) {
				turnLeft();
				b=1;
			}
			else {
				if(getDirection()==Direction.RIGHT) {
					turnLeft();
					b=2;
				}
				else {
					if(getDirection()==Direction.DOWN) {
						turnLeft();
						b=3;
					}
				}
			}
		}
		if(canMove(vector[b])) {
			setX(getX() + vector[b].x);
			setY(getY() + vector[b].y);
		}
	}
	
	// ---------------------------------------------------------------------------------------------------- //
	
	private int turnOffIteration = -1;
	private final Stone relatedStone;
	private final Vector[] rotationVectors;

	/**
	 * Constructs a {@link SquareRobot}.
	 * @param stone           the related stone
	 * @param x               the x coordinate
	 * @param y               the y coordinate
	 * @param color           the color
	 * @param rotationVectors the rotation vectors
	 */
	public SquareRobot(Stone stone, int x, int y, SquareColor color, Vector... rotationVectors) {
		super(x, y);
		this.relatedStone = stone;
		this.rotationVectors = rotationVectors;
		setImageId(color.toString());
	}

	/**
	 * Returns the related stone of this square robot.
	 * @return the related stone of this square robot
	 */
	public Stone getRelatedStone() {
		return relatedStone;
	}

	/**
	 * Returns the rotation vector array of this square robot.
	 * @return the rotation vector array of this square robot.
	 */
	public Vector[] getRotationVectors() {
		return rotationVectors;
	}

	/**
	 * Returns the iteration in which this robot was turned off.<br>
	 * If the robot was not turned off, {@code -1} will be returned.
	 * @return the iteration in which this robot was turned off or {@code -1} if this robot was not turned off
	 */
	public int getTurnOffIteration() {
		return turnOffIteration;
	}

	/**
	 * Moves this robot by the given vector.
	 * @param vector the vector
	 */
	public void move(Vector vector) {
		setX(getX() + vector.x);
		setY(getY() + vector.y);
	}

	/**
	 * Moves this robot by the vector (0,-1).
	 */
	public void moveDown() {
		move(Vector.of(0, -1));
	}

	/**
	 * Moves this robot by the vector (-1,0).
	 */
	public void moveLeft() {
		move(Vector.of(-1, 0));
	}

	/**
	 * Moves this robot by the vector (1, 0).
	 */
	public void moveRight() {
		move(Vector.of(1, 0));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void turnOff() {
		if (isTurnedOff())
			return;
		super.turnOff();
		turnOffIteration = getRelatedStone().getRelatedGame().getIteration();
	}

}
