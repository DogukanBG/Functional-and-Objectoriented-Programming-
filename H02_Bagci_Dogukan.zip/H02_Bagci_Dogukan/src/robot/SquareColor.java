package robot;

public enum SquareColor {

	AQUA, BLUE, GREEN, ORANGE, PURPLE, RED, YELLOW
}
