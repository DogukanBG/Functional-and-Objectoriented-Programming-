package test;


import java.util.function.Predicate;

import collections.MyItem;
import collections.MyList;
import collections.MySet;
import diseasespreadings.Contact;
import diseasespreadings.Person;
import diseasespreadings.simulation.MCSISimulation;

/**
 * @version 1.2
 */
@SuppressWarnings("unused")
public class Main {

	// You are allowed to use this main class.

	public static void main(String[] args) {
		
		MySet<Person> person = new MySet<>();
		MySet<Person> comp = new MySet<>();
		MySet<Person> comp1 = new MySet<>();
		MySet<Person> comp2 = null;
		Person per1 = new Person("A", 1);
		Person per2 = new Person("B", 2);
		Person per3 = new Person("C", 3);
		Person per4 = new Person("D", 4);
		Person per5 = new Person("E", 5);
		Person per6 = new Person("F", 6);
		Person per7 = new Person("G", 7);
		person.add(per1);
		person.add(per2);
		person.add(per3);
		person.add(per4);
		person.add(per5);
		person.add(per6);
		person.add(per7);
//		comp.add(per4);
//		comp.add(per5);
//		comp.add(per6);
//		comp.add(per7);
//		comp1.add(per5);
//		comp1.add(per6);
//		comp1.add(per7);
		Predicate<Person> pred = x->x.getID()>4;
//		for (MyItem<Person> pers = person.head;pers!=null;pers=pers.next) {
//			System.out.print(pers.key.getName()+" ");
//			System.out.println(pred.test(pers.key));
//		}
//		MySet<Person> test = person.makeSubset(pred);
//		System.out.println(test.head.next.next.key.getID());
//		int res = test.head.key.getID();
//		System.out.println(res);
//		int result = comp.head.key.compareTo(test.head.key);
//		System.out.println(result);
//		
		person.filter(pred);
		for (MyItem<Person> pers = person.head;pers!=null;pers=pers.next) {
			System.out.print(pers.key.getName()+" " + pers.key.getID());
			System.out.println();
			
		}
//		MyList<MySet<Person>> d = new MyList<>();
//		d.add(person);
//		d.add(comp);
//		d.add(comp1);
////		d.add(comp2);
//		MySet<Person> intersection = MySet.makeIntersection(d);
//		for (MyItem<Person> pers = intersection.head;pers!=null;pers=pers.next) {
//			System.out.print(pers.key.getName()+" " + pers.key.getID());
//			System.out.println();
//		}
		
//		Person p0 = new Person("P0", 1);
//		Person p1 = new Person("P1", 2);
//		Person p2 = new Person("P2", 3);
//		Person p3 = new Person("P3", 4);
//		
//		Contact contact0to1 = new Contact(p0, p1, 0.6, 5);
//		Contact contact0to2 = new Contact(p0, p2, 0.2, 6);
//		Contact contact1to0 = new Contact(p1, p0, 0.6, 7);
//		Contact contact1to2 = new Contact(p1, p2, 0.4, 8);
//		Contact contact2to0 = new Contact(p2, p0, 0.2, 9);
//		Contact contact2to1 = new Contact(p2, p1, 0.4, 10);
//		Contact contact2to3 = new Contact(p2, p3, 0.8, 11);
//		Contact contact3to2 = new Contact(p3, p2, 0.8, 12);
//
//		
//		MySet<Contact> contacts = new MySet<>();
//		contacts.add(contact0to1);
//		contacts.add(contact0to2);
//		contacts.add(contact1to0);
//		contacts.add(contact1to2);
//		contacts.add(contact2to0);
//		contacts.add(contact2to1);
//		contacts.add(contact2to3);
//		contacts.add(contact3to2);
//		
//		MCSISimulation simulation = new MCSISimulation(p0, contacts, 1000);
//		simulation.run();
//		
////		SISimulation sim = simulation.supply();
////		sim.run();
////		System.out.println(sim.getInfections().head.key.getInfectedPerson().getID());
//	
//
//		MySet<Person> personA = simulation.getPersons_AtLeastNInfections(350);
//		MySet<Person> random = new MySet<>();
//		random.add(p3);
//		random.add(p2);
//		random.add(p1);
//		random.add(p0);
////		System.out.println(random.head==null);
//		MySet<Person> rand = MySet.sortByID(personA);
//
//		
//		for (MyItem<Person> pers = rand.head;pers!=null;pers=pers.next) {
//			System.out.println(pers.key.getName()+" " + pers.key.getID());
//		}
		
		
	}

}
