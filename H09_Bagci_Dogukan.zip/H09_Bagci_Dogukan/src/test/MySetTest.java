package test;

import static org.junit.Assert.assertEquals;

import java.util.function.Predicate;

import org.junit.jupiter.api.Test;

import collections.MyList;
import collections.MySet;
import diseasespreadings.Person;

public class MySetTest {
	
	@Test
	public void filterTest() {
		MySet<Person> person = new MySet<>();
		MySet<Person> comp = new MySet<>();
		Person per1 = new Person("A", 1);
		Person per2 = new Person("B", 2);
		Person per3 = new Person("C", 3);
		Person per4 = new Person("D", 4);
		Person per5 = new Person("E", 5);
		Person per6 = new Person("F", 6);
		Person per7 = new Person("G", 7);
		person.add(per1);
		person.add(per2);
		person.add(per3);
		person.add(per4);
		person.add(per5);
		person.add(per6);
		person.add(per7);
		comp.add(per1);
		comp.add(per2);
		comp.add(per3);
		comp.add(per4);
		Predicate<Person> pred = x->x.getID()<=4;
		person.filter(pred);
		assertEquals(person.head.key.getID(),1);
		assertEquals(person.head.next.key.getID(),2);
		assertEquals(person.head.next.next.key.getID(),3);
		assertEquals(person.head.next.next.next.key.getID(),4);
	}
	
	@Test
	public void makeSubsetTest() {
		MySet<Person> person = new MySet<>();
		MySet<Person> comp = new MySet<>();
		Person per1 = new Person("A", 1);
		Person per2 = new Person("B", 2);
		Person per3 = new Person("C", 3);
		Person per4 = new Person("D", 4);
		Person per5 = new Person("E", 5);
		Person per6 = new Person("F", 6);
		Person per7 = new Person("G", 7);
		person.add(per1);
		person.add(per2);
		person.add(per3);
		person.add(per4);
		person.add(per5);
		person.add(per6);
		person.add(per7);
		comp.add(per4);
		comp.add(per5);
		comp.add(per6);
		comp.add(per7);
		Predicate<Person> pred = x->x.getID()>=4;
		MySet<Person> test = person.makeSubset(pred);
		assertEquals(test.head.key.compareTo(comp.head.key), 0);
		assertEquals(test.head.next.key.compareTo(per5),0);
		assertEquals(test.head.next.next.key.compareTo(per6),0);
		assertEquals(test.head.next.next.next.key.compareTo(per7),0);
		assertEquals(test.head.next.next.next.next,null);
		
	}
	
	public void makeIntersectionTest() {
		MySet<Person> person = new MySet<>();
		MySet<Person> comp = new MySet<>();
		MySet<Person> comp1 = new MySet<>();
		Person per1 = new Person("A", 1);
		Person per2 = new Person("B", 2);
		Person per3 = new Person("C", 3);
		Person per4 = new Person("D", 4);
		Person per5 = new Person("E", 5);
		Person per6 = new Person("F", 6);
		Person per7 = new Person("G", 7);
		person.add(per1);
		person.add(per2);
		person.add(per3);
		person.add(per4);
		person.add(per5);
		person.add(per6);
		person.add(per7);
		comp.add(per4);
		comp.add(per5);
		comp.add(per6);
		comp.add(per7);
		comp1.add(per5);
		comp1.add(per6);
		comp1.add(per7);
		MyList<MySet<Person>> d = new MyList<>();
		d.add(person);
		d.add(comp);
		d.add(comp1);
		MySet<Person> intersection = MySet.makeIntersection(d);
		assertEquals(intersection.head.key.compareTo(per5), 0);
		assertEquals(intersection.head.next.key.compareTo(per6), 0);
		assertEquals(intersection.head.next.next.key.compareTo(per7), 0);
		assertEquals(intersection.head.next.next.next, null);
		
	}
}
