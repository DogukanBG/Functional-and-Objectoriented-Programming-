package diseasespreadings.simulation;




import collections.MyItem;

import collections.MyList;
import collections.MySet;
import diseasespreadings.Contact;
import diseasespreadings.Person;
import diseasespreadings.event.Infection;



/**
 * A Monte Carlo simulation of simulated disease spreadings.
 */
public class MCSISimulation implements Runnable {

	// -------------------------------------------------------------- Exercises -------------------------------------------------------------- //

	/**
	 * constructs as many single simulations as the simulationCount (the attribute) determines
	 */
	@Override
	public void run() {
		// TODO Exercise H3
		for(int i = 0; i<simulationCount;i++) {
			SISimulation sim = supply();
			sim.run();
			simulations.add(sim);
		}
	}
	
	/**
	 * Returns all persons in a MySet-Object, which have been infected at least n times in the MSCISimulation
	 * @param n the least amount of infections
	 * @return all persons in a MySet-Object, which have been infected at least n times in the MSCISimulation
	 */
	public MySet<Person> getPersons_AtLeastNInfections(int n) {
		// TODO Exercise H4
		int amountOfOccur = 0;
		MyList<SISimulation> newSimulations = getSimulations();
		MySet<Person> result = new MySet<>();
		MySet<Person> tmp = new MySet<>();

		for(MyItem<SISimulation> simulation=newSimulations.head;simulation!=null;simulation=simulation.next) {
			MySet<Infection> tmpInfec = simulation.key.getInfections();
			for(MyItem<Infection> infection = tmpInfec.head;infection!=null;infection=infection.next) {
				Person mainPerson = infection.key.getInfectedPerson();
				tmp.add(mainPerson);
			}
		}
		for (MyItem<Person> mainPerson = tmp.head; mainPerson!=null;mainPerson=mainPerson.next) {
			for(MyItem<SISimulation> simulation=newSimulations.head;simulation!=null;simulation=simulation.next) {
				MySet<Infection> tmpInfec = simulation.key.getInfections();
				for(MyItem<Infection> infection = tmpInfec.head; infection!=null;infection=infection.next) {
					Person compPerson = infection.key.getInfectedPerson();
					if (mainPerson.key.compareTo(compPerson)==0) {
						amountOfOccur++;
						if (amountOfOccur>=n) {
							result.add(compPerson);
							amountOfOccur = 0;
							break;
						}
					}
				}

			}
			amountOfOccur = 0;
		}

		return result;
	}

	// -------------------------------------------------------------- sesicrexE -------------------------------------------------------------- //

	private final Person initialInfectee;
	private final MySet<Contact> contacts;
	private final int simulationCount;

	private final MyList<SISimulation> simulations = new MyList<>();

	/**
	 * Constructs a Monte Carlo simulation whose single simulations use
	 * the given initially infected person and contact network (contact set).<br>
	 * Calling {@link MCSISimulation#run()} will create and run
	 * the given count of single simulations.
	 * @param initialInfectee the initially infected person
	 * @param contacts        the contact network
	 * @param simulationCount the count of single simulations
	 */
	public MCSISimulation(Person initialInfectee, MySet<Contact> contacts, int simulationCount) {
		this.initialInfectee = initialInfectee;
		this.contacts = contacts;
		this.simulationCount = simulationCount;
	}

	/**
	 * Constructs a single simulation and returns it.<br>
	 * <b>Use this method to construct a single simulation instead of using the constructor!</br>
	 * @return the single simulation
	 */
	public SISimulation supply() {
		return new SISimulation(initialInfectee, contacts);
	}

	/**
	 * Returns the count of single simulations.
	 * @return the count of single simulations
	 */
	public int getSimulationCount() {
		return simulationCount;
	}

	/**
	 * Returns a list containing all single simulations
	 * that were create by this Monte Carlo simulation.
	 * @return the list of all single simulations
	 */
	public MyList<SISimulation> getSimulations() {
		return simulations;
	}

	// Feel free to add further methods!

}
