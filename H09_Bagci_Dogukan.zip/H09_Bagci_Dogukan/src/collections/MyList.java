package collections;

/**
 * A generic construct used for linked lists.
 *
 * @param <T> the type of keys
 */
public class MyList<T> {

	public MyItem<T> head;

	/**
	 * Constructs an empty {@link MyList}.
	 */
	public MyList() {
		this(null);
	}

	/**
	 * Constructs a {@link MyList} using the given item as the head item.
	 * @param head the head item
	 */
	public MyList(MyItem<T> head) {
		this.head = head;
	}

	/**
	 * Sets the head item of this list.
	 * @param head
	 */
	public void setHead(MyItem<T> head) {
		this.head = head;
	}

	/**
	 * Returns the head item of this list.
	 * @return
	 */
	public MyItem<T> getHead() {
		return head;
	}

	// Feel free to add further methods here!
	
	/**
	 * Adds an element t to the end of the list
	 * @param t the given element
	 */
	public void add (MyItem<T> t) {
		if (head==null) {
			head = t;
			return;
		}
		for(MyItem<T> p = head;;p=p.next) {
			if (p.next==null) {
				p.next=t;
				t.next = null;
				return;
			}
		}
	}
	
	/**
	 * adds the element to the end of the List
	 * @param t the element
	 */
	public void add (T t) {
		MyItem<T> t1 = new MyItem<>(t); 
		if (head==null) {
			head = t1;
			return;
		}
		for(MyItem<T> p = head;;p=p.next) {
			if (p.next==null) {
				p.next=t1;
				t1.next = null;
				return;
			}
		}
	}
	
}
