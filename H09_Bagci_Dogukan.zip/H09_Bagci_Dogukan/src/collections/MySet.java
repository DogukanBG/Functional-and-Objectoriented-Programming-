package collections;



import java.util.function.Predicate;




/**
 * A generic construct used for linked sets.<br>
 * <br>
 * The item cascade that is referenced by this construct
 * must be sorted according to the natural order of the elements.
 * The item cascade may contain each item at most once!
 *
 * @param <T> the type of keys
 */

public class MySet<T extends Comparable<? super T>> implements Cloneable {

	// -------------------------------------------------------------- Exercises -------------------------------------------------------------- //
	/**
	 * Removes every element that doesn't fullfil the given predicate
	 * @param predicate the given predicate
	 */
	public void filter(Predicate<? super T> predicate) {
		// TODO Exercise H1.1
		if (head==null) {
			return;
		}
		for(MyItem<T> p = head;p!=null&&p.next!=null;p=p.next) {
			if (predicate.test(p.next.key)==false) {
				p.next = p.next.next;
			}

		}
		for(MyItem<T> p=head;p!=null;) {
			if (predicate.test(head.key)==false) {
				head = head.next;
			}
			else {
				break;
			}
		}

	}
	/**
	 * Makes a Subset with all elements that fullfil the given predicate
	 * @param predicate the given predicate
	 * @return a Subset with all elements that fullfil the given predicate
	 */
	public MySet<T> makeSubset(Predicate<? super T> predicate) {
		// TODO Exercise H1.2
		MySet<T> subSet = new MySet<>();
		MyItem<T> tail = null;
		if (head==null) {
			return subSet;
		}
		for (MyItem<T> p = head;p!=null;p=p.next) {
			if (predicate.test(p.key)) {
				if (subSet.head==null) {
					MyItem<T> item = new MyItem<T>(p.key);
					subSet.head = item;
					tail = subSet.head;
				} else {
					MyItem<T> item = new MyItem<T>(p.key);
					tail.next = item;
					tail = tail.next;
				}
			}
		}
		return subSet;
	}
	/**
	 * an intersection of all sets in the List
	 * @param <T> the type of keys
	 * @param sets the given List that contains all sets
	 * @return an intersection of all sets
	 */
	public static <T extends Comparable<? super T>> MySet<T> makeIntersection(MyList<MySet<T>> sets) {
		// TODO Exercise H1.3
		if (sets==null) {
			return new MySet<T>();
		}
		MySet<T> result = sets.head.key;
		for(MyItem<MySet<T>> set = sets.head.next;set!=null;set=set.next) {
			result = MySet.makeIntersectionOfTwo(result, set.key);
		}
		return result;
	}

	// -------------------------------------------------------------- sesicrexE -------------------------------------------------------------- //

	public MyItem<T> head;

	/**
	 * Constructs an empty {@link MySet}.
	 */
	public MySet() {
		this(null);
	}

	/**
	 * Constructs a {@link MySet} using the given item as the head item.
	 * @param head the head item
	 */
	public MySet(MyItem<T> head) {
		this.head = head;
	}

	/**
	 * Sets a new head item of this set.
	 * @param head the new head item
	 */
	public void setHead(MyItem<T> head) {
		this.head = head;
	}

	/**
	 * Returns the head item of this set.
	 * @return the head item
	 */
	public MyItem<T> getHead() {
		return head;
	}

	// Feel free to add further methods here!
	
	/**
	 * Adds an element t to the end of an MySet
	 * @param t the given element
	 */
	public void add(MyItem<T> t) {
		if (head == null) {
			head = t;
			return;
		}
		for(MyItem<T> p = head;;p=p.next) {
			if (p.next==null) {
				t.next = null;
				p.next = t;
				return;
			}
		}
	}
	/**
	 * Difference: t doesnt have to be a MyItem-Object
	 * 
	 * Adds an element t to the end of an MySet, if it isn't in the MySet already
	 * @param t the given element
	 */
	public boolean add(T t) {
		MyItem<T> t1 = new MyItem<T>(t);

		if (head == null) {
			head = t1;
			return true;
		}
		for(MyItem<T> p = head;p!=null;p=p.next) {
			if (p.key.compareTo(t)==0) {
				return false;
			}
		}
		for(MyItem<T> p = head;;p=p.next) {
			if (p.next==null) {
				t1.next = null;
				p.next = t1;
				return true;
			}
		}
	}

	/**
	 * Removes the element t if the element is in the list and not null
	 * @param t the given element
	 */
	public void remove (MyItem<T> t) {
		if (t == null) {
			return;
		}
		if (head.key.compareTo(t.key)==0) {
			head = head.next;
			return;
		}
		for(MyItem<T> p = head;;p=p.next) {
			if (p.next.key.compareTo(t.key)==0) {
				p.next=p.next.next;
				return;
			}
		}
	}
	/**
	 * Makes an Intersection of two sets
	 * @param <T>  the type of keys
	 * @param set1 the first set
	 * @param set2 the second set
	 * @return the intersection of set1 and set2
	 */
	public static <T extends Comparable<? super T>> MySet<T> makeIntersectionOfTwo(MySet<T> set1, MySet<T> set2){
		MySet<T> result = new MySet<>();
		MyItem<T> tail = null;
		if (set1==null||set2==null) {
			return result;
		}
		for (MyItem<T> item1 = set1.head;item1!=null;item1=item1.next) {
			for(MyItem<T> item2 = set2.head;item2!=null;item2=item2.next) {
				
				if (item1.key.compareTo(item2.key)==-1) {
					break;
				}
				
				if (item1.key.compareTo(item2.key)==0) {
					if (result.head==null) {
						MyItem<T> item = new MyItem<T>(item1.key);
						result.head = item;
						tail = result.head;
						
					}
					else {
						MyItem<T> item = new MyItem<T>(item1.key);
						tail.next = item;
						tail = tail.next;
					
					}
					
				}
				
			}
		}
		return result;
		
	}
	/**
	 * Returns true if the given element is in the MySet
	 * @param t the given element
	 * @return true if the given element is in the MySet
	 */
	public boolean contains (T t) {
		for(MyItem<T> item = head;head!=null;head=head.next) {
			if (item.key.compareTo(t)==0 ) {
				return true;
			}
		}
		return false;
	}

}
