package h1;

public class Fibonacci{
	/**
	 * H1.1 (1)rekursiver Ansatz fibRek(int i)
	 * 
	 * gibt den Fibonnaci-Wert an Index i wieder (i muss >= 0 sein, sonst wird -1(=keine Fibonnaci-Zahl) zur�ckgegeben)
	 * 
	 * @param i gew�nschter Index
	 * 
	 * @return Fibonacci Wert an Index i
	 */
	public static int fibRek(int i) { 
		int fib=-1;
		if(i==0) {
			return fib=0;
		}
		if(i==1) {
			return fib=1;
		}
		if(i>=2) {
			return fib = fibRek(i-1)+fibRek(i-2);
		}
		return fib;
	
	}
	
	/**
	 * H1.1 (2) iterativer Ansatz fibIt(int[] arr)
	 * 
	 * f�llt einen eindimensionalen Array (beliebige L�nge) mit Fibonacci Werten bis zum Index arr.length-1. 
	 * 
	 * @param arr beliebiges Array
	 */
	public static void fibIt(int[] arr) { 
		for(int b=0;b<arr.length;b++) {
			if (b==0) {
				arr[b]=0;
			}
			if(b==1) {
				arr[b]=1;
			}
			if(b>=2) {
				arr[b]= arr[b-1] + arr[b-2];
			}
		}
	}
	/**
	 * H1.2 fibMat (int n)
	 * 
	 * berechnet den Fibonnaci-Wert an Index n anhand von Matrizen.
	 * 
	 * @param n gew�nschter Index
	 * 
	 * @return Fibonacci Wert an Index n
	 */
	public static int fibMat(int n) { //H1.2 
		int [][]result= {{1,1},{1,0}};
		int [][] fib = {{1,1},{1,0}};
		if(n==0) {
			return result[1][1];		
		}
		if(n==1) {
			return result[0][1];
			}
		if(n>=2) {
			for(int i=1; i<n;i++) {
				result=Util.matrixMultiplication(fib,result);
			}
			return result[0][1];
		}
		return -1;
	}
	/**
	 * H1.3 fibSum(int n)
	 * 
	 * berechnet den Fibonacci-Wert an Index n mithilfe der Summenformel
	 * 
	 * @param n gew�nschter Index (n muss >=0 sein, sonst wird -1 (keine Fibonacci Zahl) zur�ckgegeben)
	 * @return Fibonacci an Index n
	 */
	public static int fibSum(int n) {
		int result = 0;
		if(n>=0) {
			if(n%2==0) {
				for(int i=0;i<n/2;i++) {
					result+=Util.binomialCoefficient((n-i),(i-1));
				}
			}
			else {
				for(int i=0;i<((n+1)/2);i++) {
					result+=Util.binomialCoefficient((n-i),(i-1));
					}
			}
		}
		else {
			return -1;
		}
		return result;
	}
	/**
	 * H1.4 collatz(int coll)
	 * 
	 * gibt die L�nge der Collatz-Folge wieder (einschlie�lich 4,2,1)
	 * collatzElements betr�gt zu Beginn 3, da die minimale L�nge der Collatz-Folge 3 betr�gt (bei Startwert 4)
	 * 
	 * @param coll gew�nschter Startwert der Collatz-Folge
	 * 
	 * @return L�nge der Collatz-Folge
	 */
	public static int collatz(int coll) { //H1.4
		int collatzElements = 3;
		while(!(coll==4))
			if(coll%2==0) {
				coll = coll/2;
				collatzElements++;
			}
			else {
				coll = coll*3+1;
				collatzElements++;
			}
		return collatzElements;
		}
	/**
	 * Diese Methode berechnet die L�nge des kleinsten ununterbrochenen Musters in einem Array,
	 * falls kein Muster vorhanden ist, liefert es den Wert -1 zur�ck
	 *  
	 * @param arr array, das gepr�ft werden soll
	 * @return die L�nge des Musters oder -1
	 */
	public static int cycle(int[]arr) {
		int cycleSize = 1;
		boolean cycleExist = true;
		if(arr.length==2) {
			if(arr[0]==arr[1]) {
				return cycleSize=1;
			}
			else {
				return cycleSize=-1;
			}
		}
		else {
			while (arr[0]!=arr[cycleSize]) {
				cycleSize++;
				if(cycleSize==arr.length) {
					break;
				}
			}
			if(arr[0]==arr[cycleSize]) {
				for(int i=0;i<arr.length-cycleSize;i++) {
					if(arr[i]!=arr[cycleSize+i]) {
						cycleExist=false;
					}
				}
			}
			if(cycleExist) {
				if(arr[cycleSize]==arr[arr.length-1]) {
					return cycleSize;
				}
				else {
					return cycleSize=-1;
				}
			}
			else {
				return cycleSize=-1;
			}
		}
		
	}
}


