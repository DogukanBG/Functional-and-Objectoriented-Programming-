package h2;

public class Leguan extends Reptil {
	/**
	 * (Konstruktor) gibt dem Leguan einen Namen sowie ein Gehege 
	 * @param name gew�nschter Name des Leguans
	 * @param gehege gew�nschtes Gehege f�r den Leguan
	 */
	public Leguan (String name,Gehege gehege) {
		super(name,gehege);
	}
	/**
	 * Beim Aufruf stellt sich der Leguan vor.
	 * (F�r die Methode vorstellen() in der Klasse Zoo wichtig)
	 * 
	 * @return Vorstellung des Leguans
	 */
	public String toString() {
		if (gehege==null) {
			return "Ich wurde noch nicht zugeteilt\n";
		}
		else{
			return "Ich bin Leguan" + name + "wohne im Gehege" + gehege + "und bin ein" + tierart+"\n"; 
		}
	}
	/**
	 * spezifische implementierung der Methode kompatibel aus der abstrakten indirekten Basisklasse Tier
	 * pr�ft ob der Leguan kompatibel mit einem anderen Tier t ist
	 * (F�r die Methode add() in Klasse Gehege wichtig)
	 * 
	 * @param t beliebige Subklasse der Klasse Tier
	 * 
	 * @return gibt an, ob Klasse Leguan kompatibel mit t ist  
	 */
	public boolean kompatibel(Tier t) {
		if (t instanceof Fledermaus) {
			return false;
		}
		else {
		return true;
		}
	}
}
