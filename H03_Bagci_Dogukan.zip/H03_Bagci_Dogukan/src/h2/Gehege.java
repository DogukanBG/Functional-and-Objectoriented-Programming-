package h2;

public class Gehege {
	String name;
	Tier[] tiere;
	
	public Gehege(String name, int size) {
		this.name = name;
		tiere = new Tier[size];
	}
	/**
	 * f�gt ein Tier t in ein Gehege ein 
	 * (vorausgesetzt es ist mit allen anderen Tieren kompatibel und es gibt einen freien Platz im Gehege)
	 * 
	 * @param t gew�nschtes Tier
	 * 
	 * @return gibt an, ob das Hinzuf�gen erfolgreich war oder, ob es fehlgeschlagen ist
	 */
	public boolean add(Tier t) {
		boolean freierPlatz = false;
		boolean mitAllenKompatibel = true;
		for(int i=0; i<tiere.length; i++) {
			if(tiere[i]==null) {
				freierPlatz = true;
			}
		}
		if(freierPlatz) {
			for(int a=0;a<tiere.length;a++) {
				if(tiere[a]!=null) {
					if(!(tiere[a].kompatibel(t))) {
						mitAllenKompatibel=false;
					}
				}
			}
		}
		if(mitAllenKompatibel==true) {
			t.umsiedeln(this);;
			return true;
		}
		else {
			return false;
		}
	}
}