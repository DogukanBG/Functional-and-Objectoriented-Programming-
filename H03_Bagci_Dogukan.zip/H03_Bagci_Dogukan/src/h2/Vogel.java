package h2;

public abstract class Vogel extends Tier {
	public Vogel(String name, Gehege gehege) {
		super(name, gehege);
	}

	final static String tierart = "Vogel";
	
}
