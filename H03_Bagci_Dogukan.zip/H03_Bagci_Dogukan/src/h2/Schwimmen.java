package h2;

public interface Schwimmen {
	/**
	 * wird in den ben�tigten Klassen implementiert
	 * erm�glicht spezifische Implementierung
	 * @return Schwimmstil
	 */
	String schwimmen();
	
}
