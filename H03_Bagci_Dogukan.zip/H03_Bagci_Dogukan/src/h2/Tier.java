package h2;

public abstract class Tier {
	public static boolean constructorCalled = false;
	protected String name;
	protected Gehege gehege;
	
	public Tier(String name, Gehege gehege) {
		constructorCalled = true;
		this.name = name;
		if(gehege != null && gehege.add(this)) this.gehege = gehege;
	}
	
	public boolean kompatibel(Tier t) {
		return true;
	}
	/**
	 * siedelt ein Tier in ein neues Gehege um
	 * @param neuesGehege gew�nschtes Gehege 
	 */
	public void umsiedeln(Gehege neuesGehege) { //H2.2
		this.gehege = neuesGehege;
	}
	
}
