package h2;

public abstract class Saeugetier extends Tier {
	public Saeugetier(String name, Gehege gehege) {
		super(name, gehege);
		// TODO Auto-generated constructor stub
	}

	final static String tierart = "Saeugetier";
}
