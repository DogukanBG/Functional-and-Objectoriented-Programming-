package h2;

public class Krokodil extends Reptil implements Schwimmen {
	/**
	 * (Konstruktor) gibt dem Krokodil einen Namen sowie ein Gehege 
	 * @param name gew�nschter Name des Krokodils
	 * @param gehege gew�nschtes Gehege f�r den Krokodil
	 */
	public Krokodil (String name,Gehege gehege) {
		super(name,gehege);
	}
	/**
	 * Beim Aufruf stellt sich der Krokodil vor.
	 * (F�r die Methode vorstellen() in der Klasse Zoo wichtig)
	 * 
	 * @return Vorstellung des Krokodils
	 */
	public String toString() {
		if (gehege==null) {
			return "Ich wurde noch nicht zugeteilt\n";
		}
		else{
			return "Ich bin Krokodil" + name + "wohne im Gehege" + gehege + "und bin ein" + tierart + "\n"; 
		} 
	}
	/**
	 * spezifische implementierung der Methode schwimmen() aus dem Interface Schwimmen
	 * verleiht dem Krokodil eine eigene Art zu schwimmen
	 * (F�r die Methode schwimmtraining() in Klasse Zoo wichtig)
	 * 
	 * @return Schwimmstil des Krokodils
	 */
	public String schwimmen() {
		return "paddeln\n";
	}
	/**
	 * spezifische implementierung der Methode kompatibel aus der abstrakten indirekten Basisklasse Tier
	 * pr�ft ob der Krokodil kompatibel mit einem anderen Tier t ist
	 * (F�r die Methode add() in Klasse Gehege wichtig)
	 * 
	 * @param t beliebige Subklasse der Klasse Tier
	 * 
	 * @return gibt an, ob Klasse Krokodil kompatibel mit t ist  
	 */
	public boolean kompatibel(Tier t) {
		if(t instanceof Emu || t instanceof Delphin || t instanceof Leguan) {
			return false;
		}
		else {
			return true;
		}
	}
}
