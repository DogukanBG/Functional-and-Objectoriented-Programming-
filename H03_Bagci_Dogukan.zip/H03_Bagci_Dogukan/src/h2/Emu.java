package h2;

public class Emu extends Vogel {
	/**
	 * (Konstruktor) gibt dem Emu einen Namen sowie ein Gehege 
	 * @param name gew�nschter Name des Emus
	 * @param gehege gew�nschtes Gehege f�r den Emu
	 */
	public Emu (String name,Gehege gehege) {
		super(name,gehege);
	}
	/**
	 * Beim Aufruf stellt sich der Emu vor.
	 * (F�r die Methode vorstellen() in der Klasse Zoo wichtig)
	 * 
	 * @return Vorstellung des Emus
	 */
	public String toString() {
		if (gehege==null) {
			return "Ich wurde noch nicht zugeteilt\n";
		}
		else{
			return "Ich bin Emu" + name + "wohne im Gehege" + gehege + "und bin ein" + tierart+ "\n";
		}
	}
	/**
	 * spezifische implementierung der Methode kompatibel aus der abstrakten indirekten Basisklasse Tier
	 * pr�ft ob der Emu kompatibel mit einem anderen Tier t ist
	 * (F�r die Methode add() in Klasse Gehege wichtig)
	 * 
	 * @param t beliebige Subklasse der Klasse Tier
	 * 
	 * @return gibt an, ob Klasse Emu kompatibel mit t ist  
	 */
	public boolean kompatibel (Tier t) {
		if (t instanceof Kolibri || t instanceof Krokodil || t instanceof Fledermaus) {
			return false;
		}
		else {
			return true;
		}
	}
	
}
