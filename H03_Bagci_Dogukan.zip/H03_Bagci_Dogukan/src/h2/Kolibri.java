package h2;

public class Kolibri extends Vogel implements Fliegen {
	/**
	 * (Konstruktor) gibt dem Kolibri einen Namen sowie ein Gehege 
	 * @param name gew�nschter Name des Kolibris
	 * @param gehege gew�nschtes Gehege f�r den Kolibri
	 */
	public Kolibri (String name,Gehege gehege) {
		super(name,gehege);
	}
	/**
	 * Beim Aufruf stellt sich der Kolibri vor.
	 * (F�r die Methode vorstellen() in der Klasse Zoo wichtig)
	 * 
	 * @return Vorstellung des Kolibris
	 */
	public String toString() {
		if (gehege==null) {
			return "Ich wurde noch nicht zugeteilt\n";
		}
		else{
			return "Ich bin Kolibri" + name + "wohne im Gehege" + gehege + "und bin ein" + tierart + "\n"; 
		} 
	}
	/**
	 * spezifische implementierung der Methode fliegen() aus dem Interface Fliegen
	 * verleiht dem Kolibri eine eigene Art zu fliegen
	 * (F�r die Methode flugshow() in Klasse Zoo wichtig)
	 * 
	 * @return Flugstil des Kolibris
	 */
	public String fliegen() {
		return "schnelles flattern\n";
	}
	/**
	 * spezifische implementierung der Methode kompatibel aus der abstrakten indirekten Basisklasse Tier
	 * pr�ft ob der Kolibri kompatibel mit einem anderen Tier t ist
	 * (F�r die Methode add() in Klasse Gehege wichtig)
	 * 
	 * @param t beliebige Subklasse der Klasse Tier
	 * 
	 * @return gibt an, ob Klasse Kolibri kompatibel mit t ist  
	 */
	public boolean kompatibel(Tier t) {
		if(t instanceof Emu) {
			return false;
		}
		else {
			return true;
		}
	}
}
