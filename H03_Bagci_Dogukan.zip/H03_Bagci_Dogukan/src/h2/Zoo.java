package h2;

public class Zoo {
	public static Tier[] tiere;
	public static Gehege[] gehege;
	/**
	 * Alle Tiere im tiere Array stellen sich vor, 
	 * indem die jeweilige Implementierung der Methode toString mit jeder Komponente des Arrays aufgerufen wird 
	 * (nur mit den initialisierten Komponenten)
	 * 
	 * @return nacheinander stellen sich die Tiere vor
	 */
	public static String vorstellen() {
		String vorstell = "";
		for(int i=0;i<tiere.length;i++) {
			if(tiere[i]!=null) {
				vorstell += tiere[i].toString();
			}
		}
		return vorstell;
	}
	/**
	 *die Tiere, voraussgesetzt sie k�nnen fliegen, im tiere Array performen eine "Flugshow",
	 *indem die jeweilige Implementierung der Methode fliegen() aufgerufen wird
	 * 
	 * @return Flugshow
	 */
	public static String flugshow() {
		String flugSh = "";
		for (int i=0;i<tiere.length;i++) {
			if (tiere[i] instanceof Fledermaus || tiere[i] instanceof Kolibri) {
				if(tiere[i] instanceof Fledermaus) {
					flugSh += ((Fledermaus)tiere[i]).fliegen();
				}
				if(tiere[i] instanceof Kolibri) {
					flugSh +=((Kolibri)tiere[i]).fliegen();
				}
			}
		}
		return flugSh;
	}
	/**
	 * die Tiere, die schwimmen k�nnen, im tiere Array haben ein "Schwimmtraining" 
	 * daf�r wird die jeweilige Implementierung der Methode schhwimmen() aufgerufen
	 * @return
	 */
	public static String schwimmtraining() {
		String schwimmTr = "";
		for (int i=0;i<tiere.length;i++) {
			if(tiere[i] instanceof Delphin || tiere[i] instanceof Krokodil) {
				if(tiere[i]instanceof Delphin) {
					schwimmTr += ((Delphin) tiere[i]).schwimmen();
				}
				if(tiere[i] instanceof Krokodil) {
					schwimmTr += ((Krokodil)tiere[i]).schwimmen();
				}
				
			}
		}
		return schwimmTr;
	}
	
}
