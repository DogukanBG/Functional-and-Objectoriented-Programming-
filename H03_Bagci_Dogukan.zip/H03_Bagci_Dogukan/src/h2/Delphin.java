package h2;

public class Delphin extends Saeugetier implements Schwimmen {
	/**
	 * (Konstruktor) gibt dem Delphin einen Namen sowie ein Gehege 
	 * @param name gew�nschter Name des Delphins
	 * @param gehege gew�nschtes Gehege f�r das Delphin
	 */
	public Delphin (String name,Gehege gehege) {
		super(name,gehege);
	}
	/**
	 * Beim Aufruf stellt sich der Delphin vor.
	 * (F�r die Methode vorstellen() in der Klasse Zoo wichtig)
	 * 
	 * @return Vorstellung des Delphins
	 */
	public String toString() {
		if (gehege==null) {
			return "Ich wurde noch nicht zugeteilt\n";
		}
		else{
			return "Ich bin Delphin" + name + "wohne im Gehege" + gehege + "und bin ein" + tierart +"\n";
		}
	}
	/**
	 * spezifische implementierung der Methode schwimmen() aus dem Interface Schwimmen
	 * verleiht dem Delphin eine eigene Art zu schwimmen
	 * (F�r die Methode schwimmtraining() in Klasse Zoo wichtig)
	 * 
	 * @return Schwimmstil des Delphins
	 */
	public String schwimmen() {
		return "elegantes schwimmen\n";
	}
	/**
	 * spezifische implementierung der Methode kompatibel aus der abstrakten indirekten Basisklasse Tier
	 * pr�ft ob der Delphin kompatibel mit einem anderen Tier t ist
	 * (F�r die Methode add() in Klasse Gehege wichtig)
	 * 
	 * @param t beliebige Subklasse der Klasse Tier
	 * 
	 * @return gibt an, ob Klasse Delphin kompatibel mit t ist  
	 */
	public boolean kompatibel(Tier t) {
		if(t instanceof Krokodil) {
			return false;
		}
		else {
			return true;
		}
	}
}
