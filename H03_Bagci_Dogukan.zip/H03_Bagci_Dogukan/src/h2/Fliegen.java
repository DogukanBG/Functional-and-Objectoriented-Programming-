package h2;

public interface Fliegen {
	/**
	 * wird in den ben�tigten Klassen implementiert
	 * erm�glicht spezifische Implementierung
	 * @return Flugstil
	 */
	String fliegen();
}
