package h2;

public abstract class Reptil extends Tier {
	public Reptil(String name, Gehege gehege) {
		super(name, gehege);
		// TODO Auto-generated constructor stub
	}

	final static String tierart = "Reptil";
}
