/**
 * Enthält die UI-Komponenten, mit denen das Game of Life gesteuert und
 * dargestellt werden kann.
 *
 * @author Kim Berninger
 * @version 1.0.1
 */
package life.ui;
