/**
 * Enthält verschiedene Farbschemata zur Darstellung von Zellzuständen.
 *
 * @author Kim Berninger
 * @version 1.0.1
 */
package life.ui.color;
