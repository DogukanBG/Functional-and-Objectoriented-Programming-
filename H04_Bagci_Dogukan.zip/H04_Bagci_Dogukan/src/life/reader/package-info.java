/**
 * Enthält die Klassen und Interfaces zum Einlesen von Zuständen von zellulären
 * Automaten aus Textdateien.
 *
 * @author Kim Berninger
 * @version 1.0.1
 */
package life.reader;
