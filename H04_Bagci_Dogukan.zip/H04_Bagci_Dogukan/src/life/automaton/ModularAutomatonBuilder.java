package life.automaton;

import life.automaton.neighborhood.Neighborhood;
import life.automaton.neighborhood.Padding;
import life.automaton.rules.UpdateRules;
import life.automaton.state.AutomatonState;

public class ModularAutomatonBuilder implements CellularAutomatonBuilder {
	private AutomatonState state=null;
	private UpdateRules rules=null;
	private Neighborhood neighborhood=null;
	private Padding padding=null;
	
	/*public ModularAutomatonBuilder(AutomatonState state,UpdateRules rules,Neighborhood neighborhood,Padding padding) {
		this.state=null;
		this.rules=null;
		this.neighborhood=null;
		this.padding=null;
	}
	*/
	@Override
	public CellularAutomatonBuilder addState(AutomatonState state) {
		this.state=state;
		return new ModularAutomatonBuilder();
	}

	@Override
	public CellularAutomatonBuilder addRules(UpdateRules rules) {
		this.rules=rules;
		return new ModularAutomatonBuilder();
	}

	@Override
	public CellularAutomatonBuilder addNeighborhood(Neighborhood neighborhood) {
		this.neighborhood=neighborhood;
		return new ModularAutomatonBuilder();
	}

	@Override
	public CellularAutomatonBuilder addPadding(Padding padding) {
		this.padding=padding;
		return new ModularAutomatonBuilder();
	}

	@Override
	public CellularAutomaton buildAutomaton() {
		return new ModularAutomaton(state,rules,neighborhood,padding);
	}

}
