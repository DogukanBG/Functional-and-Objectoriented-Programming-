package life.automaton;


import life.automaton.neighborhood.Neighborhood;
import life.automaton.neighborhood.Padding;
import life.automaton.rules.UpdateRules;
import life.automaton.state.AutomatonState;


public class ModularAutomaton implements CellularAutomaton {
	private AutomatonState initialState;
	private AutomatonState currentState;
	private UpdateRules rules;
	private Neighborhood neighborhood;
	private Padding padding;
	
	public ModularAutomaton(AutomatonState initialState,UpdateRules rules,
			Neighborhood neighborhood,Padding padding) {
		this.initialState=initialState;
		this.currentState=initialState;
		this.rules=rules;
		this.neighborhood=neighborhood;
		this.padding=padding;
	}
	
	
	@Override
	public boolean isAlive(int row, int col) {
		return currentState.isAlive(row, col);
	}

	@Override
	public int getHeight() {
		return currentState.getHeight();
	}

	@Override
	public int getWidth() {
		return currentState.getWidth();
	}

	@Override
	public void update() {
		AutomatonState localState = currentState;
		for (int row = 0; row < localState.getHeight(); row++) {
            for (int col = 0; col < localState.getWidth(); col++) {
            	if(rules.getNextCellState(padding.isAlive(localState, row, col),neighborhood.getNumberOfAliveNeighbors(localState,row,col,padding))) {
            		localState.giveBirth(row, col);
            	}
            	else {
            		localState.kill(row, col);
            	}
            }
		}
		currentState=localState;
	}

	@Override
	public void reset() {
		currentState=initialState;

	}

}
