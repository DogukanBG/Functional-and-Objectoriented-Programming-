package life.automaton.neighborhood;

import life.automaton.state.AutomatonState;

public class MooreNeighborhood implements Neighborhood{
	public int getNumberOfAliveNeighbors(AutomatonState state, int row, int col, Padding padding) {
		int result=0;
		for(int i=-1;i<2;i++) {
			for(int b=-1;b<2;b++) {
				if(!((row+i==row)&&(col+b==col))){
					result+=padding.isAlive(state, row+i, col+b)?1:0;
				}
			}
		}
	return result;
	}
}
