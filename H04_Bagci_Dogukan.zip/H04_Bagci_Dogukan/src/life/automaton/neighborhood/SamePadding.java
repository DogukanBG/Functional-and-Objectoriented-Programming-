package life.automaton.neighborhood;

import life.automaton.state.AutomatonState;

public class SamePadding implements Padding {
	@Override
	public boolean isAlive(AutomatonState state, int row, int col) {
		boolean alive=false;
		if(1<=row && row<state.getHeight()-1&&1<=col&&col<state.getWidth()-1) {
			alive = state.isAlive(row, col);
		}
		if(row>=state.getHeight()-1&&1<=col&&col<state.getWidth()-1) {
			alive = state.isAlive(state.getHeight()-1, col);
		}
		if(row<=0&&1<=col && col<state.getWidth()-1) {
			alive = state.isAlive(0, col);
		}
		if(1<=row&&row<state.getHeight()-1&&col>=state.getWidth()-1) {
			alive = state.isAlive(row, state.getWidth()-1);
		}
		if(1<=row&&row<state.getHeight()-1&&col<0) {
			alive = state.isAlive(row, 0);
		}
		if(row>=state.getHeight()-1&&col>=state.getWidth()-1) {
			alive=state.isAlive(state.getHeight()-1, state.getWidth()-1);
		}
		if(row<=0&&col<=0) {
			alive=state.isAlive(0, 0);
		}
		if(row<=0&&col>=state.getWidth()-1) {
			alive=state.isAlive(0, state.getWidth()-1);
		}
		if(row>=state.getHeight()-1&&col<=0) {
			alive=state.isAlive(state.getHeight()-1, 0);
		}
		return alive;
	}
}
