package life.automaton.neighborhood;

import life.automaton.state.AutomatonState;

public class DonutPadding implements Padding {
	@Override
	public boolean isAlive(AutomatonState state, int row, int col) {
		int height= state.getHeight();
		int width= state.getWidth();
		boolean isAlive=false;
		if(0<=row&&row<height&&0<=col&&col<width) {
			isAlive=state.isAlive(row, col);
		}
		if(0<=row&&row<height&&col>=width) {
			isAlive=state.isAlive(row, col-width);
		}
		if(row>=height&&0<=col&&col<width) {
			isAlive=state.isAlive(row-height, col);
		}
		if(0<=row&&row<height&&col<0) {
			isAlive=state.isAlive(row, width+col);
		}
		if(row<0&&0<=col&&col<width) {
			isAlive=state.isAlive(height+row, col);
		}
		if(row>=height&&col>=width) {
			isAlive=state.isAlive(row-height, col-width);
		}
		if(row<0&&col>=width) {
			isAlive=state.isAlive(height+row, col-width);
		}
		if(row>=height&&col<0) {
			isAlive=state.isAlive(row-height, width+col);
		}
		if(row<0&&col<0) {
			isAlive=state.isAlive(height+row, width+col);
		}
		return isAlive;
	}
}
