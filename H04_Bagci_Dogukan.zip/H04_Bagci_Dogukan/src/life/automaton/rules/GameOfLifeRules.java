package life.automaton.rules;


public class GameOfLifeRules implements UpdateRules {
	@Override
	public boolean getNextCellState(boolean isAlive, int aliveNeighbors) {
		return isAlive?((aliveNeighbors==2||aliveNeighbors==3)?true:false):((aliveNeighbors==3)?true:false);
	}

}
