/**
 * Enthält verschiedene Regelsätze für das Game of Life oder ähnliche Prozesse.
 *
 * @author Kim Berninger
 * @version 1.0.1
 */
package life.automaton.rules;
