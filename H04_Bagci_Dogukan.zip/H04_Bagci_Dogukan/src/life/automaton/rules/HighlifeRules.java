package life.automaton.rules;

public class HighlifeRules implements UpdateRules {

	@Override
	public boolean getNextCellState(boolean isAlive, int aliveNeighbors) {
		return isAlive?((aliveNeighbors==2||aliveNeighbors==3)?true:false):((aliveNeighbors==3||aliveNeighbors==6)?true:false);
	}

}
