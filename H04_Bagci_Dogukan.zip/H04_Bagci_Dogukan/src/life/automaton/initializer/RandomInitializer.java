package life.automaton.initializer;

import life.automaton.state.ArrayAutomatonState;
import life.automaton.state.AutomatonState;

import java.util.Random;

public class RandomInitializer implements StateInitializer {
	
	private int height;
	private int width;
	private double rate;
	
	public RandomInitializer(int height, int width, double rate) {
		this.height=height;
		this.width=width;
		this.rate=rate;
	}
	@Override
	public AutomatonState createState() {
		Random zufall=new Random();
		ArrayAutomatonState state = new ArrayAutomatonState(this.height,this.width);
		for (int row = 0; row < state.getHeight(); row++) {
            for (int col = 0; col < state.getWidth(); col++) {
            	if(zufall.nextDouble()<=this.rate) {
            		state.giveBirth(row, col);
            	}
            }
		}
		return state;
	}
}
