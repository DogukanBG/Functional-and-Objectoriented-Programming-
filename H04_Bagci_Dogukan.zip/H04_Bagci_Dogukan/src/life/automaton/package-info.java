/**
 * Enthält die Klassen und Interfaces, die verwendet werden, um zelluläre
 * Automaten mit rechteckigen Zuständen zu repräsentieren.
 *
 * @author Kim Berninger
 * @version 1.0.1
 */
package life.automaton;
