/**
 * Enthält die Klassen und Interfaces, die verwendet werden, um die Zustände von
 * zellulären Automaten zu modellieren.
 *
 * @author Kim Berninger
 * @version 1.0.1
 */
package life.automaton.state;
