package memomap;

/*
 *Klasse NotStudent wurde nur f�r die Tests definiert
 */

public class NotStudent implements Identifiable {
	
	public String name;
	
	public NotStudent(String name) {
		this.name = name;
	}

	@Override
	public int getID() throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (name.equals(other.name)) {
			return true;
		}
		return false;
	}

}
