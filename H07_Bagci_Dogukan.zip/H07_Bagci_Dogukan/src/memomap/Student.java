package memomap;

/*
 * Klasse Student wurde nur f�r die Tests definiert
 * Anmerkung: ein Student ist immer eindeutig, d.h. falls die Namen gleich sind, aber nich die id, dann sind das zwei 
 * verschiedene Personen
 */

public class Student implements Identifiable{
	
	public String name;
	public int id;
	
	public Student (String name, int id) {
		this.name = name;
		this.id = id;
	}
	
	public int getID() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	

	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (name.equals(other.name)&& id==other.id) {
			return true;
		}
		return false;
	}
}
