package memomap;





/**
 * A {@link MemoMap} is a map that maps identifiable objects to strings that are
 * also called memos.
 * <p>
 * Each identifiable object can be mapped to at most one memo. A memo may be
 * {@code null}. If a memo is finalized, the memo can no longer be changed.
 * 
 * @version 1.0
 */
public class MemoMap {

	/**
	 * The array of {@link MemoEntry} objects.
	 */
	public final MemoEntry[] entries;

	/**
	 * Constructs a {@link MemoMap} with the given capacity.
	 * 
	 * @param capacity the capacity of the memo map
	 */
	public MemoMap(int capacity) {
		if (capacity < 0) {
			throw new IllegalArgumentException("The capacity is invalid: " + capacity);
		}
		entries = new MemoEntry[capacity];
	}
	/**
	 * 
	 * Die Methode erstellt einen neuen MemoEntry in der MemoMap
	 * 
	 * @param ident das Objekt, dem die Notiz zugewiesen werden soll
	 * @param str die Notiz, die dem Objekt zugewiesen werden soll.
	 * @param bool die Angabe, ob der Eintrag finalisiert werden soll
	 * @throws WriteException wenn das gegebene Objekt die Methode getID nicht unterst�tzt
	 */
	public void put (Identifiable ident, String str, boolean bool) throws WriteException{
		if (ident == null) {
			throw new NullPointerException("The given object is null.");
		}
		boolean boo = false;
		int secondRound = ident.getID()%entries.length;
		try {
			for (int i = ident.getID()%entries.length;; i++) {
				if (boo) {
					if (i == secondRound) {
						break;
					}
				}
				if(entries[i]!=null) {
					if (entries[i].object.equals(ident)) {
						if (entries[i].finalized) {
							throw new WriteException("The memo is finalized.");
						}
						if (entries[i].finalized==false) {
							entries[i].memo= str;
							entries[i].finalized = bool;
							return;
						}
					}
				}
				if (i >= entries.length-1) {
					i = -1;
				}
				boo = true;
				
			}
			boo = false;
			boolean noEntryExist = false;
			boolean emptyEntryExist = false;
			
			for (int i = ident.getID()%entries.length;; i++) {
				if (boo) {
					if (i == secondRound) {
						break;
					}
				}
				if (entries[i]==null) {
					MemoEntry memoEntry = new MemoEntry(ident, str, bool);
					entries[i] = memoEntry;
					noEntryExist = true;
					return;
				}
				if (entries[i].memo==null && entries[i].finalized==false) {
					entries[i].object = ident;
					entries[i].memo = str;
					entries[i].finalized = bool;
					emptyEntryExist = true;
					return;
				}
				if (i >= entries.length-1) {
					i = 0;
				}
				boo = true;
			}
			if (emptyEntryExist == false && noEntryExist == false) {
				throw new WriteException("There is not enough capacity.");
			}
		} catch (UnsupportedOperationException e) {
			throw new WriteException("The object is not identifiable.");
		}
		
	}
	
	/**
	 * 
	 * Die Methode liefert die zugeh�rigen Notiz eines Objektes zur�ck
	 * 
	 * @param id  ID des Objekts 
	 * @return liefert die dem Objekt zugewiesene Notiz zur�ck
	 * @throws ReadException wenn kein Eintrag f�r ein Objekt mit der gegebenen ID existiert 
	 * 						 oder wenn der dazugeh�rige Eintrag null referenziert 
	 */
	
	public String get (int id) throws ReadException {
		if (id < 0) {
			throw new IndexOutOfBoundsException("The ID is invalid: " + id);
		}
		for (int i = id%entries.length;i!=id%entries.length-1; i++) {
			if (i >= entries.length) {
				i = 0;
			}
			if (entries[i]!=null) {
				if (entries[i].object.getID()==id) {
					if(entries[i].memo!=null) {
						return entries[i].memo;
					}
				}
			}
		}
		throw new ReadException("There is no memo assigned.");
	}
	
	/**
	 * Die Methode verschmelzt zwei Abbildungen miteinander
	 * Die Eintr�ge der �bergebenen MemoMap werden in die MemoMap eingef�gt, mit der man die Methode aufgerufen hat
	 * 
	 * @param map MemoMap, dessen Eintr�ge �bertragen werden 
	 */
	public void merge (MemoMap map) throws WriteException{
		if (map == null) {
			throw new NullPointerException("The given memo map is null.");
		}
		MemoMap mergingMap = sort(map);
		try {
			for (int i = 0; i < mergingMap.entries.length; i++) {
				if (mergingMap.entries[i] != null) {
					if (containsObject(mergingMap.entries[i].object)) {
						int pos = getPosOfSameID(mergingMap.entries[i].object);
						if (!entries[pos].finalized) {
							if (entries[pos].memo!=null && mergingMap.entries[i].memo!=null) {
								entries[pos].memo = entries[pos].memo + " " + mergingMap.entries[i].memo;
							}
							if (entries[pos].memo==null && mergingMap.entries[i].memo!=null) {
								entries[pos].memo =  mergingMap.entries[i].memo;
							}
							if (mergingMap.entries[i].finalized) {
								entries[pos].finalized = mergingMap.entries[i].finalized;
							}
						}
						else {
							throw new WriteException("There is at least non-mergeable entry");
						}
					}
				}
			}
			for (int i = 0; i < mergingMap.entries.length; i++) {
				if (mergingMap.entries[i]!=null) {
					if (!(containsObject(mergingMap.entries[i].object))) {
						put(mergingMap.entries[i].object, mergingMap.entries[i].memo, mergingMap.entries[i].finalized);
					}
				}
			}
		} catch (WriteException exc) {
			if (exc.getMessage().equals("Cannot write memo: There is at least non-mergeable entry")) {
				throw new WriteException("There is at least non-mergeable entry");
			}
			else {
				throw new WriteException("There is not enough capacity");	
			}
		}
		
	}
	/**
	 * sorts an MemoMap in ascending order of their id
	 * 
	 * @param map the given MemoMap
	 * @return the sorted MemoMap
	 */
	private static MemoMap sort(MemoMap map) {
		int p = 0;
		int notNull = 0;
		for (int i = 0; i < map.entries.length; i++) {
			if (map.entries[i]!=null) {
				notNull++;
			}
		}
		MemoMap newMap = new MemoMap(notNull);
		int [] notNulls = new int[notNull];
		for (int i = 0; i < map.entries.length; i++) {
			if (map.entries[i]!=null) {
				notNulls[p] = map.entries[i].object.getID();
				p++;
			}
		}
		for (int i = 0; i < notNulls.length; i++) {
			for (int j = i+1; j < notNulls.length; j++) {
				if (notNulls[i]>notNulls[j]) {
					int tmp = notNulls[i];
					notNulls[i] = notNulls[j];
					notNulls[j] = tmp;	
				}
			}
		}
		for (int i = 0; i < notNulls.length; i++) {
			newMap.entries[i] = map.getEntryWithSameID(notNulls[i]);
		}
		return newMap;
	}
	/**
	 * Die Methode liefert zur�ck, ob das �bergebene Objekt in der MemoMap enthalten ist oder nicht
	 * 
	 * @param ident das �bergebene Objekt
	 * @return true, wenn das Objekt in der MemoMap enthalten ist
	 */
	private boolean containsObject(Identifiable ident) {
		boolean boo = false;
		int secondRound = ident.getID()%entries.length;
		for (int i = ident.getID()%entries.length;; i++) {
			
			if (boo) {
				if (i == secondRound) {
					break;
				}
			}
			if (entries[i]!=null) {
				if (ident.equals(entries[i].object)) {
					return true;
				}
			}
			if (i >= entries.length-1) {
				i = -1;
			}
			boo = true;
			
		}
		return false;
	}
	/**
	 * Die Methode liefert den Index des �bergebenen Objektes in der MemoMap
	 * 
	 * @param ident das �bergebene Objekt
	 * @return den Index des �bergeben Objektes in der MemoMap (wenn das Objekt nicht enthalten ist wird der 
	 * "unm�gliche" Index -1 zur�ckgeliefert
	 */
	private int getPosOfSameID(Identifiable ident) {
		boolean boo = false;
		int secondRound = ident.getID()%entries.length;
		for (int i = ident.getID()%entries.length;; i++) {
			
			if (boo) {
				if (i == secondRound) {
					break;
				}
			}
			if (entries[i]!=null) {
				if (ident.equals(entries[i].object)) {
					return i;
				}
			}
			if (i >= entries.length-1) {
				i = -1;
			}
			boo = true;
			
		}
		return -1;
	}
	/**
	 * returns the MemoEntry with the same id as the given id (if the id is not in the 
	 * Memomap it will return null)
	 * 
	 * @param id the given id
	 * @return the MemoEntry with the same id
	 */
	private MemoEntry getEntryWithSameID(int id) {
		for(int i=0; i<entries.length; i++) {
			if (entries[i]!=null) {
				if (entries[i].object.getID()==id) {
					return entries[i];
				}
			}
		}
		return null;
	}
		

	

	/**
	 * 
	 * Die Methode gibt alle zugeh�rigen Notizen auf der Konsole an zusammen mit der entsprechenden id
	 * 
	 * @param ids enth�lt alle gew�nschten id's
	 */
	public void print (int[] ids) {
		for (int i = 0; i < ids.length; i++) {
			try {	
				System.out.println("["+ids[i]+"]" + get(ids[i]));
			} 
			catch (ReadException exc) {
				System.out.println(exc.getMessage());
				continue;
			} 
			catch (IndexOutOfBoundsException exc) {
				continue;
			}
		}
	}
}
