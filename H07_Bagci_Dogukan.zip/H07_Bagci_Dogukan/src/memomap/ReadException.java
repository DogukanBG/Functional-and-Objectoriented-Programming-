package memomap;

@SuppressWarnings("serial")
public class ReadException extends Exception {
	
	public ReadException(String str) {
		super("Cannot read memo: " + str);
	}
}
