package memomap;



@SuppressWarnings("serial")
public class WriteException extends Exception {

	public WriteException(String str) {
		super("Cannot write memo: " + str);
	}
}
