package memomap;

import org.junit.jupiter.api.Test;



import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.assertEquals;

public class MemoMapTest {
	
	@Test
	public void testGet () throws ReadException {
		MemoMap map =  new MemoMap(5);
		
		Student paulH = new Student("Paul Henri", 12345);
		Student paulJ = new Student("Paul Joshua", 67890);
		Student lucas = new Student("Lucas", 24680);
		Student atha = new Student("Atha", 13579);
		Student liam = new Student("Liam", 31274);
		
		MemoEntry entry1 = new MemoEntry(paulH,"Es f�ngt mit M an und endet mit...", true);
		MemoEntry entry2 = new MemoEntry(paulJ,"Du gewinnst solange du einmal mehr aufstehst als du niedergeschlagen wirst", false);
		MemoEntry entry3 = new MemoEntry(lucas,"Money is made night and day", true);
		MemoEntry entry4 = new MemoEntry(atha,"Samstags esse ich gerne Pfannkuchen", false);
		MemoEntry entry5 = new MemoEntry(liam,"Cristiano Ronaldo ist der beste Fu�ballspieler aller Zeiten", false);
		
		map.entries[0] = entry1;
		map.entries[1] = entry2;
		map.entries[2] = entry3;
		map.entries[3] = entry4;
		map.entries[4] = entry5;
		
		assertEquals("Money is made night and day", map.get(24680));
		
	}
	
	@Test
	public void testGetInvalid() {
		MemoMap map =  new MemoMap(6);
		
		Student jack = new Student("Jack", 12345);
		Student come = new Student("Come", 67890);
		Student basil = new Student("Basil", 24680);
		Student marleen = new Student("Marleen", 13579);
		Student liam = new Student("Liam", 31274);
		
		MemoEntry entry1 = new MemoEntry(jack,"Ich (m,18) suche dringend eine Freundin", true);
		MemoEntry entry2 = new MemoEntry(come,"Ich hei�e D ogukan", false);
		MemoEntry entry3 = new MemoEntry(basil,"Wer das liest ist schlau", true);
		MemoEntry entry4 = new MemoEntry(marleen,"Der Himmel ist blauer, wenn die Palmen regnen", false);
		MemoEntry entry5 = new MemoEntry(liam,"Cristiano Ronaldo ist der beste Fu�ballspieler aller Zeiten", false);
		
		map.entries[0] = entry1;
		map.entries[1] = entry2;
		map.entries[2] = entry3;
		map.entries[3] = entry4;
		map.entries[4] = entry5;
		
		ReadException exc = assertThrows(ReadException.class, ()-> map.get(49283));
		assertEquals("Cannot read memo: There is no memo assigned.", exc.getMessage());
	}
	
	@Test
	public void testPutValid() throws WriteException{
		MemoMap map1 =  new MemoMap(6);
		
		Student paulH = new Student("Paul Henri", 12345);
		Student paulJ = new Student("Paul Joshua", 67890);
		Student lucas = new Student("Lucas", 24680);
		Student atha = new Student("Atha", 13579);
		Student liam = new Student("Liam", 31274);
		Student jack = new Student("Jack", 13578);
		
		MemoEntry entry1 = new MemoEntry(paulH,"Es f�ngt mit M an und endet mit...", true);
		MemoEntry entry2 = new MemoEntry(paulJ,"Du gewinnst solange du einmal mehr aufstehst als du niedergeschlagen wirst", false);
		MemoEntry entry3 = new MemoEntry(lucas,"Money is made night and day", true);
		MemoEntry entry4 = new MemoEntry(atha,"Samstags esse ich gerne Pfannkuchen", false);
		MemoEntry entry5 = new MemoEntry(liam,"Cristiano Ronaldo ist der beste Fu�ballspieler aller Zeiten", false);
		MemoEntry entry6 = new MemoEntry(jack,"Ich (m,18) suche dringend eine Freundin", true);
		
		map1.entries[0] = entry1;
		map1.entries[1] = entry2;
		map1.entries[2] = entry3;
		map1.entries[3] = entry4;
		map1.entries[4] = entry5;
		map1.entries[5] = entry6;
		
		MemoMap map2 =  new MemoMap(6);
		
		map2.entries[0] = entry1;
		map2.entries[1] = entry2;
		map2.entries[2] = entry3;
		map2.entries[3] = entry4;
		map2.entries[4] = entry5;
		
		String string = "Ich (m,18) suche dringend eine Freundin";
		Boolean bool = true;
		map2.put(new Student("Jack", 13578),string,bool);
		assertEquals(map1.entries[5].object, map2.entries[5].object);
		assertEquals(map1.entries[5].memo, map2.entries[5].memo);
		assertEquals(map1.entries[5].finalized, map2.entries[5].finalized);
	}
	
	@Test
	public void testPutInvalid() {
		MemoMap map =  new MemoMap(5);
		
		Student jack = new Student("Jack", 12345);
		Student come = new Student("Come", 67890);
		Student basil = new Student("Basil", 24680);
		Student atha = new Student("Atha", 13579);
		Student liam = new Student("Liam", 31274);
		
		MemoEntry entry1 = new MemoEntry(jack,"Ich (m,18) suche dringend eine Freundin", true);
		MemoEntry entry2 = new MemoEntry(come,"Ich hei�e D ogukan", false);
		MemoEntry entry3 = new MemoEntry(basil,"Wer das liest ist schlau", true);
		MemoEntry entry4 = new MemoEntry(atha,"Samstags esse ich gerne Pfannkuchen", false);
		MemoEntry entry5 = new MemoEntry(liam,"Cristiano Ronaldo ist der beste Fu�ballspieler aller Zeiten", false);
		
		map.entries[0] = entry1;
		map.entries[1] = entry2;
		map.entries[2] = entry3;
		map.entries[3] = entry4;
		map.entries[4] = entry5;
		
		WriteException exc = assertThrows(WriteException.class,()->map.put(new Student("Jack",12345), "A", false));
		assertEquals("Cannot write memo: The memo is finalized.", exc.getMessage());
	}
	
	@Test
	public void testMergeValid() throws WriteException {
		
		MemoMap map2 =  new MemoMap(6);
		
		Student paulH = new Student("Paul Henri", 12345);
		Student paulJ = new Student("Paul Joshua", 67890);
		Student lucas = new Student("Lucas", 24680);
		Student atha = new Student("Atha", 13579);
		Student liam = new Student("Liam", 31274);
		Student jack = new Student("Jack", 13578);
		Student come = new Student("Come", 67890);
		Student basil = new Student("Basil", 24680);
		Student moawis = new Student("Moawis", 73629);
		
		MemoEntry entry1 = new MemoEntry(paulH,"Es f�ngt mit M an und endet mit...", true);
		MemoEntry entry2 = new MemoEntry(paulJ,"Du gewinnst solange du einmal mehr aufstehst als du niedergeschlagen wirst", false);
		MemoEntry entry3 = new MemoEntry(lucas,"Money is made night and day", true);
		MemoEntry entry4 = new MemoEntry(atha,"Samstags esse ich gerne Pfannkuchen", false);
		MemoEntry entry5 = new MemoEntry(liam,"Cristiano Ronaldo ist der beste Fu�ballspieler aller Zeiten", false);
		MemoEntry entry6 = new MemoEntry(jack,"Ich (m,18) suche dringend eine Freundin", true);
		MemoEntry entry7 = new MemoEntry(come, "Ich hei�e D ogukan", true);
		MemoEntry entry8 = new MemoEntry(basil, "Wer das liest, ist schlau", false);
		MemoEntry entry9 = new MemoEntry(moawis, "Happiness can be found, even in the darkest of times, if one only remembers"
				+ "to turn on the light. -Alfred Dumbledore", false);
		
		map2.entries[0] = entry1;
		map2.entries[1] = entry2;
		map2.entries[2] = entry3;
		map2.entries[3] = entry4;
		map2.entries[4] = entry5;
		
		MemoMap map1 = new MemoMap(20);
		
		map1.entries[0] = entry7;
		map1.entries[1] = entry8;
		map1.entries[2]	= entry6;
		map1.entries[3] = entry9;
		
		map1.merge(map2);
		assertEquals(map2.entries[0].object, map1.entries[5].object);
		assertEquals(map2.entries[0].memo, map1.entries[5].memo);
		assertEquals(map2.entries[0].finalized, map1.entries[5].finalized);
	}
	
	@Test
	public void testMergeInvalid() {
		MemoMap map2 =  new MemoMap(6);
		
		Student paulH = new Student("Paul Henri", 12345);
		Student paulJ = new Student("Paul Joshua", 67890);
		Student lucas = new Student("Lucas", 24680);
		Student atha = new Student("Atha", 13579);
		Student liam = new Student("Liam", 31274);
		Student jack = new Student("Jack", 13578);
		Student come = new Student("Come", 67890);
		Student basil = new Student("Basil", 24680);
		Student moawis = new Student("Moawis", 73629);
		
		MemoEntry entry1 = new MemoEntry(paulH,"Es f�ngt mit M an und endet mit...", true);
		MemoEntry entry2 = new MemoEntry(paulJ,"Du gewinnst solange du einmal mehr aufstehst als du niedergeschlagen wirst", false);
		MemoEntry entry3 = new MemoEntry(lucas,"Money is made night and day", true);
		MemoEntry entry4 = new MemoEntry(atha,"Samstags esse ich gerne Pfannkuchen", false);
		MemoEntry entry5 = new MemoEntry(liam,"Cristiano Ronaldo ist der beste Fu�ballspieler aller Zeiten", false);
		MemoEntry entry6 = new MemoEntry(jack,"Ich (m,18) suche dringend eine Freundin", true);
		MemoEntry entry7 = new MemoEntry(come, "Ich hei�e D ogukan", true);
		MemoEntry entry8 = new MemoEntry(basil, "Wer das liest, ist schlau", false);
		MemoEntry entry9 = new MemoEntry(moawis, "Happiness can be found, even in the darkest of times, if one only remembers"
				+ "to turn on the light. -Alfred Dumbledore", false);
		MemoEntry testEntry = new MemoEntry(jack,"a", false);
		
		map2.entries[0] = entry1;
		map2.entries[1] = entry2;
		map2.entries[2] = entry3;
		map2.entries[3] = entry4;
		map2.entries[4] = entry5;
		
		MemoMap map1 = new MemoMap(20);
		
		map1.entries[0] = entry7;
		map1.entries[1] = entry8;
		map1.entries[2]	= entry6;
		map1.entries[3] = entry1;
		map1.entries[4] = entry9;
		map1.entries[5] = testEntry;
		
		WriteException exc = assertThrows(WriteException.class, ()->map1.merge(map2));
		assertEquals("Cannot write memo: There is at least non-mergeable entry", exc.getMessage());
	}
	
	
}
